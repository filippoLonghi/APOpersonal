from tkinter import *
from tkinter import ttk
from tkinter import messagebox
from chess.board import Board, Piece, ChessException
from chess.manager import ChessManager
from chess.competition import Player

class View(Tk):
    def __init__(self, model, controller):
        super().__init__()
        self._board = model
        self._controller = controller

        self.title("Chess")
        self.minsize(500, 300)
        self.columnconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)
        self.rowconfigure(2, weight=1)
        self.rowconfigure(1, weight=1)
        self.rowconfigure(0, weight=1)

        self._x = StringVar()
        self._y = StringVar()
        self._x_label = ttk.Label(self, text="X: ")
        self._y_label = ttk.Label(self, text="Y: ")
        self._x_entry = ttk.Entry(self, textvariable=self._x)
        self._y_entry = ttk.Entry(self, textvariable=self._y)
        self._x_label.grid(column=0, row=0, sticky=(N, S, W, E))
        self._y_label.grid(column=0, row=1, sticky=(N, S, W, E))
        self._x_entry.grid(column=1, row=0, sticky=(N, S, W, E))
        self._y_entry.grid(column=1, row=1, sticky=(N, S, W, E))

        self._b1 = ttk.Button(self, text="Remove piece", command=self.remove_piece)
        self._b2 = ttk.Button(self, text="Obtain piece", command=self.obtain_piece)
        self._b1.grid(column=0, row=2, sticky=(N, S, W, E))
        self._b2.grid(column=1, row=2, sticky=(N, S, W, E))

    def obtain_piece(self):
        x = self._x.get()
        y = self._y.get()
        try:
            piece = self._board.get_piece(int(x), int(y))
        messagebox.showinfo(title="Piece", message=piece)

    def remove_piece(self):
        pass
    #
    # def obtain_piece(self):
    #     win = Toplevel(self)
    #     win.title('Obtain piece')
    #     win.minsize(500, 100)
    #     win.columnconfigure(0, weight=1)
    #     win.rowconfigure(1, weight=1)
    #     win.rowconfigure(0, weight=1)
    #
    #
    #
    #     # creo messaggio con tipo e nome elementi
    #     elm_str = "\n".join(["{} {}".format(type(element).__name__, element.get_name()) for element in hsys.get_elements()])
    #     messagebox.showinfo(title="Elements", message=elm_str)
    #
    # # gestisco aggiunta studente
    # def add_element(win, name, elm_type):
    #     # creo elemento del tipo voluto
    #     if elm_type == "Source":
    #         element = Source(name)
    #     elif elm_type == "Tap":
    #         element = Tap(name)
    #     elif elm_type == "Split":
    #         element = Split(name)
    #     elif elm_type == "Sink":
    #         element = Sink(name)
    #
    #     # lo aggiungo, segnalo successo, chiudo finestra
    #     hsys.add_element(element)
    #     messagebox.showinfo(title="Success!", message="{} {} added".format(elm_type, name))
    #     # chiudo finestra
    #     win.destroy()
    #
    #
    # def show_add_element_window():
    #     # creo finestra
    #     win = Toplevel(root)
    #     win.title('Add element')
    #     win.minsize(500, 100)
    #
    #     # configuro griglia
    #     win.columnconfigure(0, weight=1)
    #     win.rowconfigure(0, weight=1)
    #     win.rowconfigure(1, weight=1)
    #     win.rowconfigure(2, weight=1)
    #     win.rowconfigure(3, weight=1)
    #     win.rowconfigure(4, weight=1)
    #     win.rowconfigure(5, weight=1)
    #     win.rowconfigure(6, weight=1)
    #     win.rowconfigure(7, weight=1)
    #
    #     # creo label
    #     l1 = ttk.Label(win, text="Nome: ")
    #     l1.grid(column=0, row=0, sticky=(N, S, W, E))
    #
    #     # creo entry
    #     name = StringVar()
    #     name_entry = ttk.Entry(win, textvariable=name)
    #     name_entry.grid(column=0, row=1, sticky=(N, S, W, E))
    #
    #     # creo radio buttons
    #     elm_type = StringVar()
    #     source = ttk.Radiobutton(win, text='Source', variable=elm_type, value='Source')
    #     tap = ttk.Radiobutton(win, text='Tap', variable=elm_type, value='Tap')
    #     split = ttk.Radiobutton(win, text='Split', variable=elm_type, value='Split')
    #     sink = ttk.Radiobutton(win, text='Sink', variable=elm_type, value='Sink')
    #
    #     # posiziono radio buttons
    #     source.grid(column=0, row=2, sticky=(N, S, W, E))
    #     tap.grid(column=0, row=3, sticky=(N, S, W, E))
    #     split.grid(column=0, row=4, sticky=(N, S, W, E))
    #     sink.grid(column=0, row=5, sticky=(N, S, W, E))
    #
    #     # creo bottone conferma
    #     b = ttk.Button(win, text="Aggiungi", command=lambda: add_element(win, name.get(), elm_type.get()))
    #     b.grid(column=0, row=6, sticky=(N, S, W, E))




class Controller:
    def __init__(self, model):
         self._board = model
         self._view = None

    def set_view(self, view):
        self._view = view

def main():
    m = Board("b", 5)
    m.add_piece(Piece.ROOK, 0, 0)
    m.add_piece(Piece.KING, 4, 4)
    m.add_piece(Piece.BISHOP, 2, 3)
    m.add_piece(Piece.PAWN, 3, 0)
    c = Controller(m)
    v = View(m, c)
    c.set_view(v)
    v.mainloop()

main()