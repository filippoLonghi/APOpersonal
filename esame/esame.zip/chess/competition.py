class Player:
    def __init__(self, name: str, nationality: str, age: int) -> None:
        pass

    def __repr__(self) -> str:
        pass


